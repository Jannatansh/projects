const body=document.querySelector("body");
header=document.querySelector("header"),
menuOpen=document.querySelector(".fa-bars-staggered"),
navbarCollapse=document.querySelector(".navbar-collapse"),backToTop=document.getElementById("backToTop");
console.log(body);
menuOpen.onclick= () =>{
    navbarCollapse.classList.toggle("show");
menuOpen.classList.toggle("fa-xmark");
};
backToTop.oneclick=()=>{
    window.scrollTo({top:0 ,behavior:"smooth"});
};
window.onscroll=()=>{
    if(document.documentElement.scrollTop>5){
        header.classList.add("sticky-on-top");
    }else{
        header.classList.remove("sticky-on-top");
    }
}
window.onload=function(){
    let elements=document.getElementsByClassName("txt-rotate");
    for (let i = 0; i< elements.length; i++) {
        console.log (elements[i].getAttribute('data-period '));
        let toRotate=elements[i].getAttribute("data-rotate")
        let period=elements[i].getAttribute("data-rotate")
        if(toRotate){
            new TxtRotate(elements[i],JSON.parse(toRotate),period);
        }
    }
    var css=document.createElement("style");
    css.type="text/css";
    css.innerHTML=".txt-rotate >.wrap { border-right:0.8rem solid #F26921}"
    document.body.appendChild(css);
} 
var TxtRotate =function(el,toRotate,period){
    this.toRotate=toRotate;
    this.el=el;
    this.loopNum=0;
    this.period=parseInt(period,100)||4000;
    this.txt="";
    this.tick();
    this.isDeleting=false;
}
TxtRotate.prototype.tick=function(){
    var i =this.loopNum%this.toRotate.length;
    var FullTxt=this.toRotate[i];
    if(this.isDeleting){
        this.txt=fullTxt.substring(0,this.txt.length-1);
    }else   {
        this.txt=Fulltxt.substring(0,this.txt.length+1);
    }
    this.el.innerHTML= '<span class="wrap">${this.txt}</span>'
    var that=this;
    var delta=150-Math.random()*100;
    if(this.isDeleting){
        delta/2;
    }
    if(!this.isDeleting && this.txt === FullTxt){
        delta=this.period;
        this.isDeleting=true;
    }else if(that.isDeleting && this.txt ===" "){
            this.isDeleting=false;
            this.loopNum++;
            delta=1000;
        }
    setTimeout(function(){
        that.tick();
    },delta);
}
